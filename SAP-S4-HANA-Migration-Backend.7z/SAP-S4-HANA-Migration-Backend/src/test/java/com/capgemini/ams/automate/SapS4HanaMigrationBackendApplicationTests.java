package com.capgemini.ams.automate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SapS4HanaMigrationBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
