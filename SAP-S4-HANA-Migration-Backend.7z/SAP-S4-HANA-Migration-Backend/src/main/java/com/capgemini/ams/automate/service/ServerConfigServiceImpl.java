package com.capgemini.ams.automate.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.ams.automate.model.ServerConfig;
import com.capgemini.ams.automate.repository.ServerConfigRepository;
@Service
public class ServerConfigServiceImpl implements ServerConfigService {

	@Autowired
	private ServerConfigRepository serverconfigRepository;
	@Override
	public HashMap<String,String> findByAllValues(String host, String client, String username) {
		List<ServerConfig> allList = serverconfigRepository.findAll();
		HashMap<String,String> hMap = new HashMap<String,String>();
		for(ServerConfig serv:allList) {
			if(serv.getServerIp().equalsIgnoreCase(host) && serv.getClient().equalsIgnoreCase(client)
					&& serv.getSapUsername().equalsIgnoreCase(username)) {
				String password = serv.getSapPassword();
				String systemNumber = serv.getSystemnumber();
				
				hMap.put("password", password);
				hMap.put("systemNumber",systemNumber);
			}
		}
		return hMap;
	}

}
