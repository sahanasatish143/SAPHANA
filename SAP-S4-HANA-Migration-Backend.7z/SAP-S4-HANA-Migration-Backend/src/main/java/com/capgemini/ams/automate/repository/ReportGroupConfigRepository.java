package com.capgemini.ams.automate.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.ams.automate.model.ReportGroupConfig;
@Repository

public interface ReportGroupConfigRepository extends JpaRepository<ReportGroupConfig, Integer>{

	@Query("select reportGroupName from  ReportGroupConfig")
	List<String> getAllreportgroupname();
	
	/*
	 * @Query("select reportGroupId from  ReportGroupConfig  where reportGroupName = :reportGroupName"
	 * ) List<Integer> getAllreportid(@Param("reportGroupName") String
	 * reportGroupName);
	 */
	long countByreportGroupName(String reportGroupName);

	@Transactional
	Long deleteByReportgroupid(long id);

	
	@Transactional
	@Modifying
	@Query("update ReportGroupConfig u set  u.reportnamelist = :reportnamelist where u.reportGroupName = :reportgroupname")
	void updateReportGroup(@Param("reportnamelist") String reportnamelist,@Param("reportgroupname") String reportgroupname);
}


