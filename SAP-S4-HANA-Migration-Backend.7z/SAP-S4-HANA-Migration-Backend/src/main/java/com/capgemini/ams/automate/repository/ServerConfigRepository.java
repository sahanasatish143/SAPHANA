package com.capgemini.ams.automate.repository;

import java.util.Collection;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.ams.automate.model.ServerConfig;
import com.capgemini.ams.automate.model.SystemType;



@Repository
public interface ServerConfigRepository extends JpaRepository<ServerConfig, Integer>{

	
	
	
}
