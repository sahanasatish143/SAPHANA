package com.capgemini.ams.automate.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.ams.automate.model.ReportMaster;

@Repository
public interface ReportConfigurationDataRepository extends JpaRepository<ReportMaster, String> {
	
	
	List<ReportMaster> findByReportgroupAndReportname(String reportgroup,String reportname);
	
	@Transactional
	Long deleteByReportgroup(String reportgroup);

	
	@Transactional
	@Modifying
	@Query("update ReportMaster u set  u.reportnamelistarray = :reportnamelistarray where u.reportgroup = :reportgroup and u.reportname = :reportname ")
	void updateReportConfiguration(@Param("reportgroup") String reportgroup, @Param("reportname") String reportname,
			 @Param("reportnamelistarray") String reportnamelistarray);



	



}
