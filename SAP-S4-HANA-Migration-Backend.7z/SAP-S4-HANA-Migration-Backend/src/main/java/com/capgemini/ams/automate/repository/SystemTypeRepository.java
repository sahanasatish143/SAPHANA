package com.capgemini.ams.automate.repository;

import java.util.Collection;

import org.springframework.dao.DataAccessException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.ams.automate.model.ServerConfig;
import com.capgemini.ams.automate.model.SystemType;


/**
 * @author Vitaliy Fedoriv
 *
 */
@Repository
public interface SystemTypeRepository extends JpaRepository<SystemType, Integer>{
	
//	SystemType findById(int id) throws DataAccessException;
//	
//	Collection<SystemType> findAll() throws DataAccessException;

	

}
