package com.capgemini.ams.automate.service;

import javax.annotation.Resource;

import com.capgemini.ams.automate.repository.ReportGroupConfigRepository;
import com.capgemini.ams.automate.repository.ReportMasterRepository;

public class JoinQueryServiceReportGroup {

	@Resource
	private ReportGroupConfigRepository reportGroupConfigRepository;
	
	
	@Resource
	private ReportMasterRepository reportMasterRepository;
	


}
