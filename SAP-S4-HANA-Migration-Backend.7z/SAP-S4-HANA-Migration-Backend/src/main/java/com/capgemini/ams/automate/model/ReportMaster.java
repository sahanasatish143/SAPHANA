package com.capgemini.ams.automate.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.Data;

@Entity
@Table(name = "tbl_report_master", 
uniqueConstraints={
	    @UniqueConstraint(columnNames = {"reportgroup","reportname"})
	})
@Data
public class ReportMaster {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int reportid;

	@Column(name = "reportname")
	private String reportname;
	
	

	@Column(name = "reportgroup")
	private String reportgroup;



	@Column(name = "createdby")
	private String createdBy;



	@Column(name = "lastupdatedby")
	private String lastUpdatedBy;

	@Column(name = "reportnamelistarray")
	private String reportnamelistarray;

	public int getReportId() {
		return reportid;
	}

	public void setReportId(int reportId) {
		this.reportid = reportId;
	}

//	public ReportGroupConfig getReportid() {
//		return reportid;
//	}
//
//	public void setReportid(ReportGroupConfig reportid) {
//		this.reportid = reportid;
//	}

	public String getreportname() {
		return reportname;
	}

	public void setreportname(String reportname) {
		this.reportname = reportname;
	}

	public String getreportnamelistarray() {
		return reportnamelistarray;
	}

	public void setreportnamelistarray(String reportnamelistarray) {
		this.reportnamelistarray = reportnamelistarray;
	}


	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getReportgroup() {
		return reportgroup;
	}

	public void setReportgroup(String reportgroup) {
		this.reportgroup = reportgroup;
	}
	
	public ReportMaster(String reportgroup, String reportname, String reportnamelistarray) {
		super();
		this.reportname = reportname;
		this.reportgroup = reportgroup;
		this.reportnamelistarray = reportnamelistarray;
	}

	public ReportMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

}
