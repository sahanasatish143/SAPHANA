package com.capgemini.ams.automate.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
*
*
* @author Nischala 
*/
@Entity
@Table(name = "loginUser")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoginPageUser {
	/**
	*
	*
	* userId
	*/
	@Id
	private String userId;
	/**
	*
	*
	* password
	*/
	
	//encrypt and decrypt
	/*
	 * @ColumnTransformer( read = "asdesktop_uat.pgp_sym_decrypt("
	 * +"password::bytea, " + "    'p123'" + ")", write =
	 * "asdesktop_uat.pgp_sym_encrypt( " + "    ?, " + "    'p123'" + ") " )
	 */
	
	
	private String password;
	

	public String getUserId() {
		return userId;
	}
	/**
	*
	*
	* setUserId
	*/
	public void setUserId(final String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	/**
	*
	*
	* setPassword
	*/
	public void setPassword(final String password) {
		this.password = password;
	}

	
	
	

}
