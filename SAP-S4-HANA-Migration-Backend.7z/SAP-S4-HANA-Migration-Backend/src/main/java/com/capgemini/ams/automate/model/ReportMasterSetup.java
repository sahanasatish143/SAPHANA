package com.capgemini.ams.automate.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "tbl_reportmaster_setup")
@Data
public class ReportMasterSetup {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "reportname")
	private String reportname;
	
	

	@Column(name = "reportvariants")
	private String reportvariants;

	


	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getReportname() {
		return reportname;
	}



	public void setReportname(String reportname) {
		this.reportname = reportname;
	}



	public String getReportvariants() {
		return reportvariants;
	}



	public void setReportvariants(String reportvariants) {
		this.reportvariants = reportvariants;
	}



	public ReportMasterSetup(String reportname, String reportvariants) {
		super();
		this.reportname = reportname;
		this.reportvariants = reportvariants;
	}



	public ReportMasterSetup() {
		super();
	}
	
	
	
	
	
}
