package com.capgemini.ams.automate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Properties;

import com.sap.conn.jco.JCoContext;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoFunctionTemplate;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoRepository;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;
import com.sap.conn.jco.ext.DestinationDataProvider;

@SpringBootApplication
public class SapS4HanaMigrationBackendApplication {

	

		public static void main(String[] args) {
		SpringApplication.run(SapS4HanaMigrationBackendApplication.class, args);
	}

	//static String destinationName = "mySAPSystem";
//	public static void main(String[] args) {
//
//		String DESTINATION_NAME1 = "mySAPSystem";
//		// this all values are coming from angular manage run user selection
//		String host = "10.8.112.4";
//		String client = "800";
//		String username = "microID";
//	
//		// String reportGroup = repp.getReportGroupName();
//		// getting password from the db based on user selection in manage run
//			//HashMap<String,String> hMap = servConfigService.findByAllValues(host, client, username);
//		String password = "Pass@123";
//		String sysno = "00";
//
//		JCoDestination destination;
//
//		System.out.println("host" + host + "client" + client + "username" + username + "password" + password + "sysno"
//				+ sysno + "=====================");
//		try {
//			Properties connectionProperty = new Properties();
//			connectionProperty.setProperty(DestinationDataProvider.JCO_ASHOST, host);
//			connectionProperty.setProperty(DestinationDataProvider.JCO_CLIENT, client);
//			connectionProperty.setProperty(DestinationDataProvider.JCO_USER, username);
//			connectionProperty.setProperty(DestinationDataProvider.JCO_PASSWD, password);
//			connectionProperty.setProperty(DestinationDataProvider.JCO_SYSNR, sysno);
//			connectionProperty.setProperty(DestinationDataProvider.JCO_LANG, "en");
//			int testSap = createDestinationDataFile(DESTINATION_NAME1, connectionProperty);
//
//			if (testSap == 1) {
//				System.out.println("test connection success");
//			} else {
//				System.out.println("fail conn===========");
//			}
//
//			destination = JCoDestinationManager.getDestination(destinationName);
//			destination.ping();
//			JCoContext.begin(destination);
//		
//			JCoFunction function1 = destination.getRepository().getFunction("BAPI_XMI_LOGON");
//
//			function1.getImportParameterList().setValue("EXTCOMPANY", "CG");
//
//			function1.getImportParameterList().setValue("EXTPRODUCT", "SAP");
//			//
//			function1.getImportParameterList().setValue("INTERFACE", "XBP");
//			//
//			function1.getImportParameterList().setValue("VERSION", "3.0");
//			//
//			function1.execute(destination);
//
//			//
//			System.out.println("RFC - XMI Logon Successfull");
//
//			JCoRepository sapRepository = destination.getRepository();
//			// JCoFunctionTemplate template = sapRepository.getFunctionTemplate(function2);
//			JCoFunction function = sapRepository.getFunction("BAPI_XBP_JOB_OPEN");
//			JCoParameterList input = function.getImportParameterList();
//			input.setValue("JOBNAME", "ReportGroup1");
//			input.setValue("EXTERNAL_USER_NAME", "microID");
//			function.execute(destination);
//			System.out.println("function executed BAPI");
//			JCoStructure ldataTable = function.getExportParameterList().getStructure("RETURN");// ).getTable();
//
//			String messageText = ldataTable.getString("MESSAGE");
//			if (ldataTable.getString("TYPE").equals("E") || ldataTable.getString("TYPE").equals("A")) {
//				System.out.println(messageText);
//
//			} else if (ldataTable.getString("TYPE").equals("W")) {
//				System.out.println("A warning message appeared: " + messageText);
//
//			} else {
//				System.out.println("bapi successfully BAPI_XBP_JOB_OPEN");
//				JCoFunction function21 = sapRepository.getFunction("BAPI_XBP_JOB_ADD_ABAP_STEP");
//				function21.getImportParameterList().setValue("JOBNAME", "REPORTGROUP2");
//				function21.getImportParameterList().setValue("EXTERNAL_USER_NAME", "microID");
//				function21.getImportParameterList().setValue("ABAP_PROGRAM_NAME", "ZTEST_15");
//				function21.getImportParameterList().setValue("ABAP_VARIANT_NAME", "TEST");
//				function21.getImportParameterList().setValue("SAP_USER_NAME", "microID");
//				function21.getImportParameterList().setValue("LANGUAGE", "en");
//				function21.execute(destination);
//
//				
//				JCoStructure ldataTableJobAbap = function21.getExportParameterList().getStructure("RETURN");
//						messageText = ldataTableJobAbap.getString("MESSAGE");
//				if (ldataTable.getString("TYPE").equals("E") || ldataTable.getString("TYPE").equals("A")) {
//					System.out.println(messageText);
//
//				} else if (ldataTable.getString("TYPE").equals("W")) {
//					System.out.println("A warning message appeared: " + messageText);
//
//				} else {
//					System.out.println("bapi successfully BAPI_add step");
//
//				}
//				JCoFunction function5 = sapRepository.getFunction("BAPI_XBP_JOB_START_ASAP");
//				function5.getImportParameterList().setValue("JOBNAME", "ReportGroup1");
//				function5.getImportParameterList().setValue("EXTERNAL_USER_NAME", "microID");
//				function5.execute(destination);
//
//				JCoStructure ldataTableJobstart = function5.getExportParameterList().getStructure("RETURN");
//				messageText = ldataTableJobstart.getString("MESSAGE");
//				if (ldataTable.getString("TYPE").equals("E") || ldataTable.getString("TYPE").equals("A")) {
//					System.out.println(messageText);
//
//				} else if (ldataTable.getString("TYPE").equals("W")) {
//					System.out.println("A warning message appeared: " + messageText);
//
//				} else {
//					System.out.println("bapi successfully starting job successfully");
//
//				}
//
////				JCoFunction function4 = sapRepository.getFunction("BAPI_XBP_JOB_CLOSE");
////				function4.getImportParameterList().setValue("JOBNAME","Reportgroup1");
////				function4.getImportParameterList().setValue("EXTERNAL_USER_NAME", "microID");
////				function4.execute(destination);
//				JCoContext.end(destination);
//			}
//
////			   
//
////			    
//			//
////			    JCoFunction function6 = mRepository.getFunction("RSPO_DOWNLOAD_SPOOLJOB");
////			    function6.getImportParameterList().setValue("ID", "31801");
////			    function6.getImportParameterList().setValue("FNAME", "abc");
//			//
////			    function6.execute(destination);	
//		} catch (Exception e) {
//			System.out.println("exception");
//		}
//
//	}
//
//	private static int createDestinationDataFile(String destinationName, Properties connectProperties) {
//		File destCfg = new File(destinationName + ".jcoDestination");
//		try {
//			FileOutputStream fos = new FileOutputStream(destCfg, false);
//			connectProperties.store(fos, "for tests only !");
//			fos.close();
//			JCoDestination destination = JCoDestinationManager.getDestination(destinationName);
//			destination.ping();
//			return 1;
//		} catch (Exception e) {
//			System.out.println("Unable to create the SAP destination files " + e.toString());
//			return 0;
//
//		}
//	}
}
