package com.capgemini.ams.automate.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_manage_monitor")

public class Monitor {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int monitorid;
	
	@Column(name = "datetime")
	private Timestamp datetime;

	@Column(name = "serverhost")
	private String serverHost;
	
	@Column(name="systemid")
	private String systemId;
	
	@Column(name="systemnumber")
	private String systemNumber;
	

	
	@Column(name="clientid")
	private String clientId;
	
	

	
	@Column(name="status")
	private String status;
	
	@Column(name="logslocation")
	private String logsLocation;
	
	@Column(name="username")
	private String username;
	
	@Column(name="reportgroupname")
	private String reportgroupname;

	@Column(name="reportstatus")
	private Integer reportstatus;

	public int getMonitorid() {
		return monitorid;
	}

	public void setMonitorid(int monitorid) {
		this.monitorid = monitorid;
	}

	

	public String getServerHost() {
		return serverHost;
	}

	public void setServerHost(String serverHost) {
		this.serverHost = serverHost;
	}

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getSystemNumber() {
		return systemNumber;
	}

	public void setSystemNumber(String systemNumber) {
		this.systemNumber = systemNumber;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getLogsLocation() {
		return logsLocation;
	}

	public void setLogsLocation(String logsLocation) {
		this.logsLocation = logsLocation;
	}

	public String getReportgroupname() {
		return reportgroupname;
	}

	public void setReportgroupname(String reportgroupname) {
		this.reportgroupname = reportgroupname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Integer getReportstatus() {
		return reportstatus;
	}

	public void setReportstatus(Integer reportstatus) {
		this.reportstatus = reportstatus;
	}

	public Timestamp getDatetime() {
		return datetime;
	}

	public void setDatetime(Timestamp datetime) {
		this.datetime = datetime;
	}

}