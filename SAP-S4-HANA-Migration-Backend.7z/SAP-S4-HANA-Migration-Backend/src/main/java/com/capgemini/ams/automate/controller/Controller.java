package com.capgemini.ams.automate.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.net.SocketTimeoutException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.capgemini.ams.automate.exception.ResourceNotFoundException;
import com.capgemini.ams.automate.model.LoginPageUser;
import com.capgemini.ams.automate.model.Manage;
import com.capgemini.ams.automate.model.Monitor;
import com.capgemini.ams.automate.model.ReportGroupConfig;
import com.capgemini.ams.automate.model.ReportMaster;
import com.capgemini.ams.automate.model.ReportMasterSetup;
import com.capgemini.ams.automate.model.ServerConfig;
import com.capgemini.ams.automate.model.SystemType;
import com.capgemini.ams.automate.repository.LoginPageUserRepo;
import com.capgemini.ams.automate.repository.ManageRepository;
import com.capgemini.ams.automate.repository.MonitorRepository;
import com.capgemini.ams.automate.repository.ReportConfigurationDataRepository;
import com.capgemini.ams.automate.repository.ReportGroupConfigRepository;
import com.capgemini.ams.automate.repository.ReportMasterRepository;
import com.capgemini.ams.automate.repository.ReportMasterSetupRepo;
import com.capgemini.ams.automate.repository.ServerConfigRepository;
import com.capgemini.ams.automate.repository.SystemTypeRepository;
import com.capgemini.ams.automate.service.ServerConfigService;
import com.sap.conn.jco.JCoContext;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoFunctionTemplate;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoRepository;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.ext.DestinationDataProvider;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/")
public class Controller {

	
	static String ids="2341";
//	String id2="1009";
//	String id3="188";
	String jobname="ReportGroup1";
	String spoolist="";
	String parameters="";
	String status="released";

	/**
	 *
	 *
	 * LoginPageUserRepo
	 */
	@Autowired
	private LoginPageUserRepo userRepo;

	@Autowired
	private ServerConfigRepository serverconfigRepository;

	@Autowired
	private ManageRepository manageRepository;

	@Autowired
	private SystemTypeRepository systemTypeRepository;

	@Autowired
	private ReportGroupConfigRepository reportGroupConfigRepository;

	@Autowired
	private ServerConfigService servConfigService;

	@Autowired
	private ReportMasterRepository reportMasterRepository;

	@Autowired
	private ReportMasterSetupRepo reportMasterSetupRepository;

	static String destinationName = "mySAPSystem";

	static String messageType;
	static JCoDestination destination;
	static JCoFunctionTemplate template;
	private static final Logger logger = Logger.getLogger(Controller.class.getName());

	private final SimpleDateFormat DATE_TIME_FORMAT = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

	@Autowired
	private ReportConfigurationDataRepository reportConfigurationDataRepo;

	@Autowired
	private MonitorRepository monitorRepository;

	/**
	 *
	 *
	 * loginUser
	 */
	@PostMapping("/login")
	public ResponseEntity<?> loginUser(@RequestBody final LoginPageUser userData)
			throws SocketTimeoutException, SQLException {

		System.out.println("login");

		System.out.println(userData);

		ResponseEntity<?> result;
		try {
			System.out.println("login");

			final LoginPageUser loginUser = userRepo.findByUserIdAndPassword(userData.getUserId(),
					userData.getPassword());
			System.out.println("login");

			if (!loginUser.toString().isEmpty()) {
				System.out.println("login");

				result = ResponseEntity.status(HttpStatus.OK).body(loginUser);

			} else {

				result = ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
						.body("username and password didn't match");

			}

		}

		catch (Exception e) {
			result = ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body("not successful");
		}

		return result;
	}

	// get all server-config
	@GetMapping("configs-list")
	public List<ServerConfig> getAllConfigs() {
		return serverconfigRepository.findAll();
	}

	// create server-config rest api
	@PostMapping("save-config")
	public ResponseEntity<ServerConfig> createServerConfig(@RequestBody ServerConfig serverConfig) {
		try {

			// serverConfig.setSyssid(2);
			serverConfig.setLastconnectionflag(0);
			// serverConfig.setLastconnectionstatus("Failure");
			ServerConfig servConf = serverconfigRepository.save(serverConfig);
			// .getClient(), serverConfig.getSapUsername(),
			// serverConfig.getSapPassword(),parseTimestamp(""),parseTimestamp(""),"Failure",0));

			return new ResponseEntity<>(servConf, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	// get server-config by id rest api
	@GetMapping("/configs-list/{id}")
	public ResponseEntity<ServerConfig> getConfigById(@PathVariable Integer id) {
		ServerConfig serverConfig = serverconfigRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Config not exist with id :" + id));
		return ResponseEntity.ok(serverConfig);
	}

	// update server-config rest api

	@PutMapping("update-config/{id}")
	public ResponseEntity<ServerConfig> updateConfig(@PathVariable Integer id,
			@RequestBody ServerConfig serverDetails) {
		ServerConfig serverConfig = serverconfigRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Config not exist with id :" + id));

		serverConfig.setClient(serverDetails.getClient());// .setFirstName(employeeDetails.getFirstName());
		serverConfig.setSystemnumber(serverDetails.getSystemnumber());
		serverConfig.setRouterString(serverDetails.getRouterString());
		serverConfig.setSapPassword(serverDetails.getSapPassword());
		serverConfig.setSapUsername(serverDetails.getSapUsername());
		serverConfig.setServerIp(serverDetails.getServerIp());
		serverConfig.setSysId(serverDetails.getSysId());
		serverConfig.setSyssid(serverDetails.getSyssid());

		ServerConfig updatedServerConfig = serverconfigRepository.save(serverConfig);
		return ResponseEntity.ok(updatedServerConfig);
	}

	// delete employee rest api
	@DeleteMapping("delete-list")
	public ResponseEntity<HttpStatus> deleteEmployee(@RequestParam Integer id) {

		try {
			serverconfigRepository.deleteById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("testconfig/{id}")
	public Integer testConfig(@PathVariable Integer id) {
		String DESTINATION_NAME1 = "mySAPSystem";
		ServerConfig serverConfig = serverconfigRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Config not exist with id :" + id));
		String client = serverConfig.getClient();// .setFirstName(employeeDetails.getFirstName());
		String password = (serverConfig.getSapPassword());
		String username = (serverConfig.getSapUsername());
		String host = (serverConfig.getServerIp());
		String sysno = serverConfig.getSystemnumber();
		logger.info("values from DB using Environment for SAP Config ");
		logger.info("sysno = " + password);
		Properties connectionProperty = new Properties();
		connectionProperty.setProperty(DestinationDataProvider.JCO_ASHOST, host);
		connectionProperty.setProperty(DestinationDataProvider.JCO_CLIENT, client);
		connectionProperty.setProperty(DestinationDataProvider.JCO_USER, username);
		connectionProperty.setProperty(DestinationDataProvider.JCO_PASSWD, password);
		connectionProperty.setProperty(DestinationDataProvider.JCO_SYSNR, sysno);
		connectionProperty.setProperty(DestinationDataProvider.JCO_LANG, "en");
		int testSap = createDestinationDataFile(DESTINATION_NAME1, connectionProperty);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		if (testSap == 1) {
			serverConfig.setLastconnectionstatus("Success");
			serverConfig.setLastconnection((parseTimestamp(dtf.format(now))));
			serverConfig.setLastsuccessfulconnection(parseTimestamp(dtf.format(now)));
			serverConfig.setLastconnectionflag(1);
			serverconfigRepository.save(serverConfig);
			return 1;
		} else {

			serverConfig.setLastconnectionstatus("Failure");
			serverConfig.setLastconnection((parseTimestamp(dtf.format(now))));
			serverConfig.setLastsuccessfulconnection(serverConfig.getLastsuccessfulconnection());
			serverConfig.setLastconnectionflag(0);
			serverconfigRepository.save(serverConfig);
			return 0;
		}

	}

	private static int createDestinationDataFile(String destinationName, Properties connectProperties) {
		File destCfg = new File(destinationName + ".jcoDestination");
		try {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			connectProperties.store(fos, "for tests only !");
			fos.close();
			JCoDestination destination = JCoDestinationManager.getDestination(destinationName);
//			
			destination.ping();
			return 1;
		} catch (Exception e) {
			System.out.println("Unable to create the SAP destination files " + e.toString());
			return 0;

		}
	}

	private java.sql.Timestamp parseTimestamp(String timestamp) {
		try {
			return new Timestamp(DATE_TIME_FORMAT.parse(timestamp).getTime());
		} catch (ParseException e) {
			throw new IllegalArgumentException(e);
		}
	}

	List<String> serverIpUniqueList = new ArrayList<String>();

	@GetMapping("manage-run")
	public List<ServerConfig> allRun() {
		return serverconfigRepository.findAll();
	}

//	@PostMapping("run-button")
//	public String runButttonBapi(@RequestBody ServerConfig serverConfig) {
//		String DESTINATION_NAME1 = "mySAPSystem";
//		// this all values are coming from angular manage run user selection
//		String host = serverConfig.getServerIp();
//		String client = serverConfig.getClient();
//		String username = serverConfig.getSapUsername();
//		String systemId = serverConfig.getSysId();
//		// String reportGroup = repp.getReportGroupName();
//		// getting password from the db based on user selection in manage run
//		HashMap<String, String> hMap = servConfigService.findByAllValues(host, client, username);
//		String password = hMap.get("password");
//		String sysno = hMap.get("systemNumber");
//
//		logger.info("values from DB using Environment for SAP Config ");
//		logger.info("sysno = " + password);
//
//		// String functionName = "BAPI_XBP_JOB_START_IMMEDIATELY";
//		JCoDestination destination;
//
//		System.out.println("host" + host + "client" + client + "username" + username + "password" + password + "sysno"
//				+ sysno + "=====================");
//		try {
//			Properties connectionProperty = new Properties();
//			connectionProperty.setProperty(DestinationDataProvider.JCO_ASHOST, host);
//			connectionProperty.setProperty(DestinationDataProvider.JCO_CLIENT, client);
//			connectionProperty.setProperty(DestinationDataProvider.JCO_USER, username);
//			connectionProperty.setProperty(DestinationDataProvider.JCO_PASSWD, password);
//			connectionProperty.setProperty(DestinationDataProvider.JCO_SYSNR, sysno);
//			connectionProperty.setProperty(DestinationDataProvider.JCO_LANG, "en");
//			int testSap = createDestinationDataFile(DESTINATION_NAME1, connectionProperty);
//
//			if (testSap == 1) {
//				System.out.println("test connection success");
//			} else {
//				System.out.println("fail conn===========");
//			}
//
//			destination = JCoDestinationManager.getDestination(destinationName);
//			destination.ping();
//			JCoContext.begin(destination);
//			String function2 = "BAPI_XMI_LOGON";
//			JCoFunction function1 = destination.getRepository().getFunction("BAPI_XMI_LOGON");
//
//			function1.getImportParameterList().setValue("EXTCOMPANY", "CG");
//
//			function1.getImportParameterList().setValue("EXTPRODUCT", "SAP");
//			//
//			function1.getImportParameterList().setValue("INTERFACE", "XBP");
//			//
//			function1.getImportParameterList().setValue("VERSION", "3.0");
//			//
//			function1.execute(destination);
//
//			//
//			System.out.println("RFC - XMI Logon Successfull");
//
//			JCoRepository sapRepository = destination.getRepository();
//			// JCoFunctionTemplate template = sapRepository.getFunctionTemplate(function2);
//			JCoFunction function = sapRepository.getFunction("BAPI_XBP_JOB_OPEN");
//			JCoParameterList input = function.getImportParameterList();
//			input.setValue("JOBNAME", reportgroupname);
//			input.setValue("EXTERNAL_USER_NAME", "microID");
//			function.execute(destination);
//			System.out.println("function executed BAPI");
//			JCoStructure ldataTable = function.getExportParameterList().getStructure("RETURN");// ).getTable();
//
//			String messageText = ldataTable.getString("MESSAGE");
//			if (ldataTable.getString("TYPE").equals("E") || ldataTable.getString("TYPE").equals("A")) {
//				System.out.println(messageText);
//
//			} else if (ldataTable.getString("TYPE").equals("W")) {
//				System.out.println("A warning message appeared: " + messageText);
//
//			} else {
//				System.out.println("bapi successfully BAPI_XBP_JOB_OPEN");
//				JCoContext.end(destination);
//			}

			//
			//
//		    JCoFunction function2 = mRepository.getFunction("BAPI_XBP_JOB_ADD_ABAP_STEP");
//		    function2.getImportParameterList().setValue("JOBNAME", "jb1");
//		    function2.getImportParameterList().setValue("EXTERNAL_USER_NAME", "sap*");
//		    function2.getImportParameterList().setValue("ABAP_PROGRAM_NAME", "RMMVRZ00");
//		    function2.getImportParameterList().setValue("ABAP_VARIANT_NAME", "KRUGMANN");
//		    function2.getImportParameterList().setValue("SAP_USER_NAME", "sap*");
//		    function2.getImportParameterList().setValue("LANGUAGE", destination.getLanguage());
//		    function2.execute(destination);
			//
//		    function3.getImportParameterList().setValue("JOBNAME", "jb1");
//		    function3.getImportParameterList().setValue("EXTERNAL_USER_NAME", "sap*");
//		    function3.getImportParameterList().setValue("EXT_PROGRAM_NAME", "RMMVRZ00");
//		    function3.getImportParameterList().setValue("SAP_USER_NAME", "sap*");
//		    function3.execute(destination);
			//
//		    JCoFunction function4 = mRepository.getFunction("BAPI_XBP_JOB_CLOSE");
//		    function4.getImportParameterList().setValue("JOBNAME", "jb1");
//		    function4.getImportParameterList().setValue("EXTERNAL_USER_NAME", "sap*");
//		    function4.execute(destination);
			//
//		    JCoFunction function5 = mRepository.getFunction("BAPI_XBP_JOB_START_ASAP");
//		    function5.getImportParameterList().setValue("JOBNAME", "jb1");
//		    function5.getImportParameterList().setValue("EXTERNAL_USER_NAME", "sap*");
//		    function5.execute(destination);
			//
//		    JCoFunction function6 = mRepository.getFunction("RSPO_DOWNLOAD_SPOOLJOB");
//		    function6.getImportParameterList().setValue("ID", "31801");
//		    function6.getImportParameterList().setValue("FNAME", "abc");
			//
//		    function6.execute(destination);	
//		} catch (Exception e) {
//			System.out.println("exception");
//		}
//		return sysno;
//
//	}

	@GetMapping("systemType")
	public List<SystemType> systemTypeValues() {
		return systemTypeRepository.findAll();
	}

	@GetMapping("reportgroupview")
	public List<ReportGroupConfig> reportGroupAll() {
		return reportGroupConfigRepository.findAll();
	}

	@GetMapping("reportmaster")
	public List<ReportMaster> reportMasterAll() {
		return reportMasterRepository.findAll();
	}

	@GetMapping("monitor")
	public List<Manage> monitorview() {
		return manageRepository.findAll();
	}

	@PostMapping(path="save-reportconfig", consumes = MediaType.APPLICATION_JSON_VALUE, 
	        produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ReportGroupConfig> createReportConfig(@RequestBody ReportGroupConfig repConfig) {
		try {

			ReportGroupConfig servConf = reportGroupConfigRepository.save(repConfig);
			return new ResponseEntity<>(servConf, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@GetMapping("reportconfigurationdata")
	public List<ReportMaster> getreportconfigurationvalue() {
		List<ReportMaster> result = new ArrayList<>();
		result = reportConfigurationDataRepo.findAll();
		return result;
	}

	@PutMapping("/updatereportconfig/")
	public ResponseEntity<ResponseMessage> updatereportconfiguration(@RequestBody List<ReportMaster> reportData,
			@RequestParam String reportnamelist) {
		String message = "";

		try {

			String deletereportgroup = reportData.get(1).getReportgroup();
			Long checkdeletereport = reportConfigurationDataRepo.deleteByReportgroup(deletereportgroup);

			for (int i = 1; i < reportData.size(); i++) {

				String reportgroup = reportData.get(i).getReportgroup();
				String reportname = reportData.get(i).getreportname();
				String reportnamelistarray = reportData.get(i).getreportnamelistarray();
				ReportMaster createnewdata = new ReportMaster(reportgroup, reportname, reportnamelistarray);
				reportConfigurationDataRepo.save(createnewdata);

				System.out.println(reportData.get(i).getreportnamelistarray());
				String reportgroupname = reportgroup;
				reportGroupConfigRepository.updateReportGroup(reportnamelist, reportgroupname);

			}

			message = "Uploaded successfully ";
			return ResponseEntity.ok(new ResponseMessage(message));

		} catch (Exception e) {
			message = "not Uploaded  ";
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
		}

	}

	@PutMapping("/addreportconfigtest/")
	public ResponseEntity<ResponseMessage> test(@RequestBody List<ReportMaster> reportData,
			@RequestParam String reportnamelist) {
		String message = "";
		System.out.println("addreportconfigtest");

		try {

			String reportgroupname = reportData.get(1).getReportgroup();
			long check = reportGroupConfigRepository.countByreportGroupName(reportgroupname);
			System.out.println("reportnamelist" + reportnamelist);

			for (int i = 1; i < reportData.size(); i++) {

				String reportgroup = reportData.get(i).getReportgroup();
				String reportname = reportData.get(i).getreportname();
				String reportnamelistarray = reportData.get(i).getreportnamelistarray();
				ReportMaster createnewdata = new ReportMaster(reportgroup, reportname, reportnamelistarray);
				reportConfigurationDataRepo.save(createnewdata);

				System.out.println(reportData.get(i).getreportnamelistarray());

			}

			ReportGroupConfig reportconfig = new ReportGroupConfig(reportgroupname, reportnamelist);
			reportGroupConfigRepository.save(reportconfig);
			message = "Uploaded successfully ";

			return ResponseEntity.ok(new ResponseMessage(message));
		} catch (Exception e) {
			message = "not Uploaded  ";
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
		}

	}

	@DeleteMapping("delete-report")
	public ResponseEntity<HttpStatus> deleteReport(@RequestParam long id, @RequestParam String reportGroupName) {
		try {

			reportGroupConfigRepository.deleteByReportgroupid(id);
			reportConfigurationDataRepo.deleteByReportgroup(reportGroupName);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// get all reportsetupdata
	@GetMapping("reportsetupdata")
	public List<ReportMasterSetup> getReportMasterSetupData() {

		return reportMasterSetupRepository.findAll();
	}

	@GetMapping("monitor-get")
	public List<Monitor> monitorGet() {
		return monitorRepository.findAll();
	}	// manage-monitor
	@PostMapping("run-button")
	public ResponseEntity<Monitor> manageMonitor(@RequestBody Monitor repConfig) {
		{

			String DESTINATION_NAME1 = "mySAPSystem";
			// this all values are coming from angular manage run user selection
			System.out.println(repConfig);
			int id=repConfig.getMonitorid();
			String host = repConfig.getServerHost();
			String client = repConfig.getClientId();
			String username = repConfig.getUsername();
			String reportGroupname = repConfig.getReportgroupname();
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
			LocalDateTime now = LocalDateTime.now();

			// String reportGroup = repp.getReportGroupName();
			// getting password from the db based on user selection in manage run
			HashMap<String, String> hMap = servConfigService.findByAllValues(host, client, username);
			String password = hMap.get("password");
			String sysno = hMap.get("systemNumber");

			JCoDestination destination;

			System.out.println("host" + host + "client" + client + "username" + username + "password" + password
					+ "sysno" + sysno + "=====================");
			try {
				Properties connectionProperty = new Properties();
				connectionProperty.setProperty(DestinationDataProvider.JCO_ASHOST, host);
				connectionProperty.setProperty(DestinationDataProvider.JCO_CLIENT, client);
				connectionProperty.setProperty(DestinationDataProvider.JCO_USER, username);
				connectionProperty.setProperty(DestinationDataProvider.JCO_PASSWD, password);
				connectionProperty.setProperty(DestinationDataProvider.JCO_SYSNR, sysno);
				connectionProperty.setProperty(DestinationDataProvider.JCO_LANG, "en");
				int testSap = createDestinationDataFile(DESTINATION_NAME1, connectionProperty);

				
				destination = JCoDestinationManager.getDestination(destinationName);
				destination.ping();
				
				
				//BAPI CALLS starts from here
				JCoContext.begin(destination);

				JCoFunction function1 = destination.getRepository().getFunction("BAPI_XMI_LOGON");

				function1.getImportParameterList().setValue("EXTCOMPANY", "CG");

				function1.getImportParameterList().setValue("EXTPRODUCT", "SAP");
			
				function1.getImportParameterList().setValue("INTERFACE", "XBP");
				
				function1.getImportParameterList().setValue("VERSION", "3.0");
				
				function1.execute(destination);

				
				System.out.println("RFC - XMI Logon Successfull");

				JCoRepository sapRepository = destination.getRepository();
				
				JCoFunction function = sapRepository.getFunction("BAPI_XBP_JOB_OPEN");
				JCoParameterList input = function.getImportParameterList();
				input.setValue("JOBNAME", reportGroupname);
				input.setValue("EXTERNAL_USER_NAME",username);
				function.execute(destination);
				System.out.println("function executed BAPI");
				JCoStructure ldataTable = function.getExportParameterList().getStructure("RETURN");// ).getTable();

				String messageText = ldataTable.getString("MESSAGE");
				if (ldataTable.getString("TYPE").equals("E") || ldataTable.getString("TYPE").equals("A")) {
					System.out.println(messageText);
					repConfig.setReportstatus(0);

					repConfig.setStatus(messageText);

				} else if (ldataTable.getString("TYPE").equals("W")) {
					System.out.println("A warning message appeared: " + messageText);
					repConfig.setReportstatus(0);

					repConfig.setStatus(messageText);

				} else {
					System.out.println("bapi successfully BAPI_XBP_JOB_OPEN");
					JCoFunction function21 = sapRepository.getFunction("BAPI_XBP_JOB_ADD_ABAP_STEP");
					function21.getImportParameterList().setValue("JOBNAME", reportGroupname);
					function21.getImportParameterList().setValue("EXTERNAL_USER_NAME",username);
					function21.getImportParameterList().setValue("ABAP_PROGRAM_NAME", "ZTEST_15");
					function21.getImportParameterList().setValue("ABAP_VARIANT_NAME", "TEST");
					function21.getImportParameterList().setValue("SAP_USER_NAME",username);
					function21.getImportParameterList().setValue("LANGUAGE", "en");
					function21.execute(destination);

					JCoStructure ldataTableJobAbap = function21.getExportParameterList().getStructure("RETURN");
					messageText = ldataTableJobAbap.getString("MESSAGE");
					if (ldataTable.getString("TYPE").equals("E") || ldataTable.getString("TYPE").equals("A")) {
						System.out.println(messageText);
						repConfig.setReportstatus(0);

						repConfig.setStatus(messageText);

					} else if (ldataTable.getString("TYPE").equals("W")) {
						System.out.println("A warning message appeared: " + messageText);
						repConfig.setReportstatus(0);

						repConfig.setStatus(messageText);

					} else {
						System.out.println("bapi successfully BAPI_add step");
						messageText = " BAPI_add step executed successfully";
						repConfig.setReportstatus(1);

						repConfig.setStatus(messageText);

					}
					JCoFunction function5 = sapRepository.getFunction("BAPI_XBP_JOB_START_ASAP");
					function5.getImportParameterList().setValue("JOBNAME",repConfig.getReportgroupname());
					function5.getImportParameterList().setValue("EXTERNAL_USER_NAME",username);
					function5.execute(destination);

					JCoStructure ldataTableJobstart = function5.getExportParameterList().getStructure("RETURN");
					messageText = ldataTableJobstart.getString("MESSAGE");
					if (ldataTable.getString("TYPE").equals("E") || ldataTable.getString("TYPE").equals("A")) {
						System.out.println(messageText);

						repConfig.setReportstatus(0);

						repConfig.setStatus(messageText);

					} else if (ldataTable.getString("TYPE").equals("W")) {

						repConfig.setReportstatus(0);

						repConfig.setStatus("A warning message appeared: " + messageText);

					} else {
						System.out.println("bapi successfully started job ");
						repConfig.setReportstatus(1);
						repConfig.setStatus("success");
						
						
						//spoolread
						JCoFunction functioSopol = sapRepository.getFunction("BAPI_XBP_JOB_START_ASAP");
						function5.getImportParameterList().setValue("JOBNAME",repConfig.getReportgroupname());
						function5.getImportParameterList().setValue("EXTERNAL_USER_NAME",username);
						function5.execute(destination);

						JCoStructure ldataTableJobfunctioSopol = function5.getExportParameterList().getStructure("RETURN");
						messageText = ldataTableJobstart.getString("MESSAGE");
						if (ldataTable.getString("TYPE").equals("E") || ldataTable.getString("TYPE").equals("A")) {
							System.out.println(messageText);

							repConfig.setReportstatus(0);

							repConfig.setStatus(messageText);

						} else if (ldataTable.getString("TYPE").equals("W")) {

							repConfig.setReportstatus(0);

							repConfig.setStatus("A warning message appeared: " + messageText);

						} else {
							System.out.println("bapi successfully started job ");
							repConfig.setReportstatus(1);
							repConfig.setStatus("success");
							JCoFunction function6 = sapRepository.getFunction("RSPO_DOWNLOAD_SPOOLJOB");
						    function6.getImportParameterList().setValue("ID", "31801");
						    function6.getImportParameterList().setValue("FNAME", repConfig.getReportgroupname());
                           // System.out.println(messageText);
						    function6.execute(destination);
						}
					}
					JCoContext.end(destination);
				 
					     
					 JFrame  f=new JFrame();    
					    String data[][]={ {ids,jobname,spoolist,status}    
					                         };    
					    String column[]={"ID","JOBNAME","SPOOLIST","Status"};         
					    JTable jt=new JTable(data,column);    
					    jt.setBounds(30,40,200,300);          
					    JScrollPane sp=new JScrollPane(jt);    
					    f.add(sp);          
					    f.setSize(300,400);    
					    f.setVisible(true);   
					    System.out.println("===BAPI REPORT===");
					    System.out.println(f);
//				
					repConfig.setClientId(client);
					repConfig.setDatetime((parseTimestamp(dtf.format(now))));

					repConfig.setServerHost(host);
                   
					repConfig.setUsername(username);
					repConfig.setReportgroupname(reportGroupname);
					
					Monitor monitorPage = monitorRepository.save(repConfig);
					return new ResponseEntity<>(monitorPage, HttpStatus.CREATED);

				}

			} catch (Exception e) {
				System.out.println("exception");
				repConfig.setMonitorid(id);
				repConfig.setClientId(client);
				repConfig.setDatetime((parseTimestamp(dtf.format(now))));
				repConfig.setReportstatus(0);
				repConfig.setServerHost(host);
				repConfig.setStatus("Failure in executing BAPIS");
				repConfig.setUsername(username);
				repConfig.setReportgroupname(reportGroupname);
				Monitor monitorPage = monitorRepository.save(repConfig);
				return new ResponseEntity<>(monitorPage, HttpStatus.CREATED);
			}

		}
		return null;
	}
}

@Configuration
@Profile("development")
class MyCorsConfig implements WebMvcConfigurer {

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/api/**").allowedOrigins("http://localhost:4200").allowedMethods("GET", "POST", "PUT",
				"PATCH", "DELETE", "OPTIONS");
	}
}
