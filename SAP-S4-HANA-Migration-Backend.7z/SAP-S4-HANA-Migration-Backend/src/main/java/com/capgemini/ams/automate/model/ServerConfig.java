package com.capgemini.ams.automate.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_serverconfiguration_view")
public class ServerConfig {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "auto_gen")
	@SequenceGenerator(name = "auto_gen", sequenceName = "A")
	@Column(name = "servconfigid")
	private int servconfigid;

	@Column(name = "serverhost")
	private String serverIp;

	@Column(name = "systemid")
	private String sysId;

	//@ManyToOne
	//@JoinColumn(name = "sysid" ,columnDefinition = "int default 1")
	@Column(name = "sysid")
	private int syssid;

	@Column(name = "systemnumber")
	private String systemnumber;

	@Column(name = "saprouterstring")
	private String routerString;

	@Column(name = "clientid")
	private String client;

	@Column(name = "username")
	private String sapUsername;

	@Column(name = "userpassword")
	private String sapPassword;

	@Column(name = "lastconnection",columnDefinition="TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Timestamp lastconnection;

	@Column(name = "lastsuccessfulconnection",columnDefinition="TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Timestamp lastsuccessfulconnection;

	@Column(name = "lastconnectionstatus",columnDefinition="Failure")
	private String lastconnectionstatus;

	@Column(name = "lastconnectionflag" ,columnDefinition="int default 0")
	private Integer lastconnectionflag;

	public ServerConfig(String serverIp, String sysId, int syssid, String systemnumber, String routerString,
			String client, String sapUsername, String sapPassword, Timestamp lastconnection,
			Timestamp lastsuccessfulconnection, String lastconnectionstatus, Integer lastconnectionflag) {

		this.serverIp = serverIp;
		this.sysId = sysId;
		this.syssid = syssid;
		this.systemnumber = systemnumber;
		this.routerString = routerString;
		this.client = client;
		this.sapUsername = sapUsername;
		this.sapPassword = sapPassword;
		this.lastconnection = lastconnection;
		this.lastsuccessfulconnection = lastsuccessfulconnection;
		this.lastconnectionstatus = lastconnectionstatus;
		this.lastconnectionflag = lastconnectionflag;
	}

	public ServerConfig() {

	}

	public int getServerconfigid() {
		return servconfigid;
	}

	public void setServerconfigid(int serverconfigid) {
		this.servconfigid = serverconfigid;
	}

	public String getServerIp() {
		return serverIp;
	}

	public void setServerIp(String serverIp) {
		this.serverIp = serverIp;
	}

	public String getSysId() {
		return sysId;
	}

	public void setSysId(String sysId) {
		this.sysId = sysId;
	}

	public int getSyssid() {
		return syssid;
	}

	public void setSyssid(int syssid) {
		this.syssid = syssid;
	}

	public String getSystemnumber() {
		return systemnumber;
	}

	public void setSystemnumber(String systemnumber) {
		this.systemnumber = systemnumber;
	}

	public String getRouterString() {
		return routerString;
	}

	public void setRouterString(String routerString) {
		this.routerString = routerString;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getSapUsername() {
		return sapUsername;
	}

	public void setSapUsername(String sapUsername) {
		this.sapUsername = sapUsername;
	}

	public String getSapPassword() {
		return sapPassword;
	}

	public void setSapPassword(String sapPassword) {
		this.sapPassword = sapPassword;
	}

	public int getServconfigid() {
		return servconfigid;
	}

	public void setServconfigid(int servconfigid) {
		this.servconfigid = servconfigid;
	}

	public Timestamp getLastconnection() {
		return lastconnection;
	}

	public void setLastconnection(Timestamp lastconnection) {
		this.lastconnection = lastconnection;
	}

	public Timestamp getLastsuccessfulconnection() {
		return lastsuccessfulconnection;
	}

	public void setLastsuccessfulconnection(Timestamp lastsuccessfulconnection) {
		this.lastsuccessfulconnection = lastsuccessfulconnection;
	}

	public String getLastconnectionstatus() {
		return lastconnectionstatus;
	}

	public void setLastconnectionstatus(String lastconnectionstatus) {
		this.lastconnectionstatus = lastconnectionstatus;
	}

	public Integer getLastconnectionflag() {
		return lastconnectionflag;
	}

	public void setLastconnectionflag(Integer lastconnectionflag) {
		this.lastconnectionflag = lastconnectionflag;
	}

	@Override
	public String toString() {
		return "ServerConfig [servconfigid=" + servconfigid + ", serverIp=" + serverIp + ", sysId=" + sysId
				+ ", syssid=" + syssid + ", systemnumber=" + systemnumber + ", routerString=" + routerString
				+ ", client=" + client + ", sapUsername=" + sapUsername + ", sapPassword=" + sapPassword
				+ ", lastconnection=" + lastconnection + ", lastsuccessfulconnection=" + lastsuccessfulconnection
				+ ", lastconnectionstatus=" + lastconnectionstatus + ", lastconnectionflag=" + lastconnectionflag + "]";
	}

}
