package com.capgemini.ams.automate.model;

public class ReportGroupReportName {

	private String reportGroupName;
	
	private String reportName;
	
	
	
	public ReportGroupReportName(String reportGroupName, String reportName) {
		
		this.reportGroupName = reportGroupName;
		this.reportName = reportName;
	}
	public String getReportGroupName() {
		return reportGroupName;
	}
	public void setReportGroupName(String reportGroupName) {
		this.reportGroupName = reportGroupName;
	}
	public String getReportName() {
		return reportName;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	@Override
	public String toString() {
		return "ReportGroupReportName [reportGroupName=" + reportGroupName + ", reportName=" + reportName + "]";
	}
}
