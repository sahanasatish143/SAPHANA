package com.capgemini.ams.automate.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_monitor_view")
public class Manage {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int monitorid;
	
	@Column(name = "datetime")
	private String datetime;

	@Column(name = "serverhost")
	private String serverHost;
	
	@Column(name="systemid")
	private String systemId;
	
	@Column(name="systemnumber")
	private String systemNumber;
	
	@Column(name="saprouterstring")
	private String sapRouterString;
	
	@Column(name="clientid")
	private String clientId;
	
	@Column(name="sysid")
	private String sysId;
	
	@Column(name="reportgroupid")
	private String reportGroupId;
	
	@Column(name="status")
	private String status;
	
	@Column(name="logslocation")
	private String logsLocation;
	
	@Column(name="createddate")
	private String createdDate;
	
	@Column(name="createby")
	private String createdBy;
	
	@Column(name="lastupdateddate")
	private String lastUpdatedDate;
	
	@Column(name="lastupdatedby")
	private String lastUpdatedBy;
	@Column(name="username")
	private String username;



	public String getUsername() {
	return username;
	}



	public void setUsername(String username) {
	this.username = username;
	}

	public int getMonitorid() {
		return monitorid;
	}

	public void setMonitorid(int monitorid) {
		this.monitorid = monitorid;
	}

	public String getDatetime() {
		return datetime;
	}

	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}

	public String getServerHost() {
		return serverHost;
	}

	public void setServerHost(String serverHost) {
		this.serverHost = serverHost;
	}

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getSystemNumber() {
		return systemNumber;
	}

	public void setSystemNumber(String systemNumber) {
		this.systemNumber = systemNumber;
	}

	public String getSapRouterString() {
		return sapRouterString;
	}

	public void setSapRouterString(String sapRouterString) {
		this.sapRouterString = sapRouterString;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getSysId() {
		return sysId;
	}

	public void setSysId(String sysId) {
		this.sysId = sysId;
	}

	public String getReportGroupId() {
		return reportGroupId;
	}

	public void setReportGroupId(String reportGroupId) {
		this.reportGroupId = reportGroupId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getLogsLocation() {
		return logsLocation;
	}

	public void setLogsLocation(String logsLocation) {
		this.logsLocation = logsLocation;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(String lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	
	
	
}
