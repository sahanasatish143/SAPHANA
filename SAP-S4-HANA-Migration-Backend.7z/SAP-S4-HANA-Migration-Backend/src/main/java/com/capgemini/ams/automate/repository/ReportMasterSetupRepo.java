package com.capgemini.ams.automate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.ams.automate.model.ReportMasterSetup;

@Repository
public interface ReportMasterSetupRepo extends JpaRepository<ReportMasterSetup, Integer>{

	

}
