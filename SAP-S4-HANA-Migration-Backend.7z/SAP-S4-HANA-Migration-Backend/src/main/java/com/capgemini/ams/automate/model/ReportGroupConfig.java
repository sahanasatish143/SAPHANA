package com.capgemini.ams.automate.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Data;

@Entity
@Table(name = "tbl_reportgroup_view")
@Data
public class ReportGroupConfig {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long reportgroupid;

	
	@Column(name = "reportgroupname",unique = true)
	private String reportGroupName;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "createddate")
	private Date createdDate = new Date();
	

	@Column(name = "createby")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "lastupdateddate")
	private Date lastUpdatedDate = new Date();
	
	
	@Column(name = "lastupdatedby")
	private String lastUpdatedBy;
	
	@Column(name="reportnamelist")
	private String reportnamelist;



//	
	public String getReportGroupName() {
		return reportGroupName;
	}

	public void setReportGroupName(String reportGroupName) {
		this.reportGroupName = reportGroupName;
	}




	public long getReportgroupid() {
		return reportgroupid;
	}

	public void setReportgroupid(long reportgroupid) {
		this.reportgroupid = reportgroupid;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}



	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	
	public String getReportnamelist() {
		return reportnamelist;
	}

	public void setReportnamelist(String reportnamelist) {
		this.reportnamelist = reportnamelist;
	}

	public ReportGroupConfig(String reportGroupName, String reportnamelist) {
		super();
		this.reportGroupName = reportGroupName;
		this.reportnamelist = reportnamelist;
	}

	public ReportGroupConfig() {
		super();
	}


	


	


	
	
	
	
}
