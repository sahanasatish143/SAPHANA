package com.capgemini.ams.automate.service;

import java.util.HashMap;

import com.capgemini.ams.automate.model.ServerConfig;

public interface ServerConfigService {
	HashMap<String,String> findByAllValues(String host,String client,String usernameS); 
	
}
