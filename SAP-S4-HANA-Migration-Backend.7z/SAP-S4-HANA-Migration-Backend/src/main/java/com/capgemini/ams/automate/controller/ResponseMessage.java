package com.capgemini.ams.automate.controller;

public class ResponseMessage {
	private String message;

	public ResponseMessage(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	/**
	 *
	 *
	 * setMessage
	 */
	public void setMessage(final String message) {
		this.message = message;
	}

}
