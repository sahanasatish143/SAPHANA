package com.capgemini.ams.automate.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("sap")
public class SAPConfig {
	
	private String username;
	private String pwd;
	private String host;
	private String systemnumber;
	private String client;
	private String lang;
	private String lastSuccessDateTime;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getSystemnumber() {
		return systemnumber;
	}

	public void setSystemnumber(String systemnumber) {
		this.systemnumber = systemnumber;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getLastSuccessDateTime() {
		return lastSuccessDateTime;
	}

	public void setLastSuccessDateTime(String lastSuccessDateTime) {
		this.lastSuccessDateTime = lastSuccessDateTime;
	}

	public String getLang() {
		return lang;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}

	@Override
	public String toString() {
		return "SAPConfig [username=" + username + ", pwd=" + pwd + ", host=" + host + ", systemnumber=" + systemnumber
				+ ", client=" + client + "]";
	}

}
