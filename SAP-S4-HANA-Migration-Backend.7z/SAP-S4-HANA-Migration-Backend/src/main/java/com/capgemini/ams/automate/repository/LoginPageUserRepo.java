package com.capgemini.ams.automate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.ams.automate.model.LoginPageUser;

/**
*
*
* @author Nischala 
*/
@Repository
public interface LoginPageUserRepo extends JpaRepository<LoginPageUser, String>{
      
	/**
	*
	*
	*  to get LoginPageUser object by userid
	*/
	@Transactional
	LoginPageUser findByUserIdAndPassword( String userId,String password);


}
